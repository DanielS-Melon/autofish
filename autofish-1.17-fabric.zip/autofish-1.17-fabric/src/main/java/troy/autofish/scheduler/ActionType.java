package troy.autofish.scheduler;

public enum ActionType {
    RECAST,
    ROD_SWITCH,
    REPEATING_ACTION,
    REEL
}
