# Autofish
A Minecraft Autofish mod for the Fabric Mod Loader

https://www.curseforge.com/minecraft/mc-mods/autofish/
